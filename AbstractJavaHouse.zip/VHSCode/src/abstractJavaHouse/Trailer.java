/*
 * sree jessu
 * Trailer
 * 04/20/2021
 * a trailer class that extends the abstract house and inherits the variables
*/
package abstractJavaHouse;

public class Trailer extends abstractHouse{

	// declare an integer variable that holds the number of wheels
	int numOfWheels;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each trailer
	 */
	@Override
	void calculateValue() {
		value = numOfWheels * numOfRooms * 2000;	
	}

	/*
	 * sree jessu
	 * doWork
	 * 04/20/2021
	 * check if more work is required and print status
	 */
	@Override
	boolean doWork() {
		workCounter++;		
		if (workCounter < workRequired){
			return false;
		}
		else {
			System.out.println("Done workin' on my Trailer!");
			return true;
		}	
	}
	
	/*
	 * sree jessu
	 * Trailer
	 * 04/20/2021
	 * stores all the required variables for the trailer; work required is constant
	 */
	Trailer(int wheels, int rooms){	
		numOfRooms = rooms;
		numOfWheels = wheels;
		workCounter = 0;
		workRequired = 10;
		calculateValue();
	}

}
