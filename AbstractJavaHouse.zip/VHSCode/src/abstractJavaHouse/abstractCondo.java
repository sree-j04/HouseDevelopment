/*
 * sree jessu
 * abstractCondo
 * 04/20/2021
 * a abstract house class that has variables used in other condo classes
*/
package abstractJavaHouse;

public abstract class abstractCondo {
	// declare a variable for the number of floors in the condo
	int numOfFloors;
	// declare a double variable for the value of each condo
	double value;
	// declare a integer variable for the hours of work required to build the condo
	int workRequired;
	// declare a integer variable that acts as a counter
	int workCounter;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each condo
	 */
	abstract void calculateValue();
	
	/*
	 * sree jessu
	 * doWork
	 * 04/20/2021
	 * calculates the amount of work done for the condos
	 */
	boolean doWork(){
		return false;	
	}
	
	/*
	 * sree jessu
	 * painted
	 * 04/20/2021
	 * checks whether or not the condo is painted
	 */
	boolean painted(){
		return false;	
	}
	
	/*
	 * sree jessu
	 * basement
	 * 04/20/2021
	 * checks whether or not the condo has basement
	 */
	boolean basement(){
		return false;	
	}
}
