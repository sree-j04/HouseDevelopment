/*
 * sree jessu
 * miniCondo
 * 04/20/2021
 * a mini condo class that extends the abstract condo and inherits the variables
*/
package abstractJavaHouse;

public class miniCondo extends abstractCondo{
	
	// declare an integer variable that holds the number of floors
	int numOfFloors;
	// declare a boolean variable for the basement
	boolean Basement;
	// declare a boolean variable for painting
	boolean Painted;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each mini condo
	 */
	@Override
	void calculateValue() {
		value = numOfFloors * 2000;
	}
	
	/*
	 * sree jessu
	 * basement
	 * 04/20/2021
	 * checks if there is basement and calculates the value and work required 
	 */
	@Override
	boolean basement() {
		if (Basement = true){
			value = value + 300;
			workRequired = workRequired + 10;
		}
		else {
			return false;
		}
		return Basement;		
	}
	
	/*
	 * sree jessu
	 * painted
	 * 04/20/2021
	 * checks if the mini condo needs to be painted and calculates value and work required
	 */
	@Override
	boolean painted() {
		if (Painted = true){
			value = value + 610;
			workRequired = workRequired + 120;
		}
		else {
			return false;
		}
		return Painted;
	}
	
	/*
	 * sree jessu
	 * miniCondo
	 * 04/20/2021
	 * stores all the required variables for the mini condo
	 */
	miniCondo(int floors, boolean hasBasement, boolean isPainted){	
		numOfFloors = floors;
		hasBasement = basement();
		isPainted = painted();
		calculateValue();
	}
}