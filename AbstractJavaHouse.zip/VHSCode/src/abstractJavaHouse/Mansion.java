/*
 * sree jessu
 * Mansion
 * 04/20/2021
 * a mansion class that extends the abstract house and inherits the variables
*/
package abstractJavaHouse;

public class Mansion extends abstractHouse{
	
	// declare an integer variable that holds the number of floors
	int numOfFloors;
	// declare a boolean variable for the driveway
	boolean Driveway;
	// declare a boolean variable for furnishing
	boolean Furnished;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each mansion
	 */
	@Override
	void calculateValue() {
		value = numOfFloors * numOfRooms * 2000;
	}
	
	/*
	 * sree jessu
	 * driveway
	 * 04/20/2021
	 * checks if there is a driveway and finds value and work required
	 */
	@Override
	boolean driveway() {
		if (Driveway = true){
			value = value + 200;
			workRequired = workRequired + 20;
		}
		else {
			return false;
		}
		return Driveway;		
	}
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each trailer
	 */
	@Override
	boolean furnished() {
		if (Furnished = true){
			value = value + 500;
			workRequired = workRequired + 100;
		}
		else {
			return false;
		}
		return Driveway;
	}
	
	/*
	 * sree jessu
	 * Mansion
	 * 04/20/2021
	 * stores all the required variables for the mansion
	 */
	Mansion(int rooms, int floors, boolean hasDriveway, boolean isFurnished){	
		numOfFloors = floors;
		numOfRooms = rooms;
		hasDriveway = driveway();
		isFurnished = furnished();
		calculateValue();
	}

}
