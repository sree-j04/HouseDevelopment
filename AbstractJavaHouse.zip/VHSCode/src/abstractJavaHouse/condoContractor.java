/*
 * sree jessu
 * condoContractor
 * 04/20/2021
 * a public class that evaluates the number of jobs, amount earned, and time taken
 * input: number of jobs, type of condo, and time taken
 * output: amount earned 
*/
package abstractJavaHouse;

import java.util.LinkedList;
import java.util.Queue;

/*
	The Contractor class has a queue of various condos that they need to do work on, 
	because the queue is created using abstract classes, they each can have the same function called and executed.
*/

public class condoContractor{
	//queue of condos to build
	Queue<abstractCondo> workQueue;
	//amount of money the contractor has earned
	double wallet;			
	//counter of the number of jobs that have been completed
	int jobCounter;					
	
	/*
	 * sree jessu
	 * condoContractor
	 * 04/20/2021
	 * default constructor that initializes the workQueue
	 */
	condoContractor(){		
		//initialize the workQueue
		workQueue = new LinkedList<abstractCondo>();
		//initialize the wallet to 0
		wallet = 0;
		//initialize the jobCounter to 0
		jobCounter = 0;											
	}
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * returns a statement that the work is done and the amount earned
	 */
	String summarizeWork(){	
		return "I completed " + jobCounter + " jobs and earned " + wallet + " dollars!";	
	}
	
	/*
	 * sree jessu
	 * randomBool
	 * 04/20/2021
	 * generates a random boolean value that has one case returns false and a default case
	 */
	boolean randomBool(){	
		switch((int)(Math.random() * 100) % 2){
			case 0:	return false;
			default:return true;		
		}	
	}
	
	/*
	 * sree jessu
	 * advertiseContract
	 * 04/20/2021
	 * generates a random boolean value, more likely to be false
	 */
	boolean advertiseContract(){	
		if (workQueue.size() < 3 && (int)Math.floor((Math.random() * 100) % 7) == 0){
			return true;	
		}
		return false;
	}
	
	/*
	 * sree jessu
	 * newJob
	 * 04/20/2021
	 * generates a job given the parameters of the condo
	 * input: random tempvalue
	 * output: job description including specs
	 */
	void newJob(){
		// random integer generator
		int tempVal = (int) ((Math.random() * 10) % 2) ;
		// declare an integer that holds the number of floors for the condo
		int tempFloors;
		
		switch(tempVal){		
			//new mini condo
			case 0:	
				// random number of floors generated
				tempFloors = (int)(Math.floor((Math.random() * 2)));				
				// add the description of the mini condo to the queue
				workQueue.add(new miniCondo(tempFloors, randomBool(),randomBool()));
				// increment job counter variable by 1
				jobCounter++;
				// statement that details the job description
				System.out.println("\nGot a new Job building a " + tempFloors + " floored mini condo!");
				break;
			
			//new large condo
			case 1: 
				// random number of floors generated
				tempFloors = (int)(Math.floor((Math.random() * 200) % 20));
				// add the description of the large condo to the queue
				workQueue.add(new largeCondo(tempFloors, randomBool(), randomBool()));
				// increment job counter variable by 1
				jobCounter++;
				// statement that details the job description
				System.out.println("\nGot a new Job building a " + tempFloors + " floored large condo!");
				break;
				// 
				
			default:
				System.out.println("Error in switch statement");	
		}	
	}
	
	/*
	 * sree jessu
	 * workLeft
	 * 04/20/2021
	 * returns true if there are houses left in queue
	 */
	boolean workLeft(){	
		return !workQueue.isEmpty();	
	}
	
	/*
	 * sree jessu
	 * doJob
	 * 04/20/2021
	 * performs 1 unit of work on the condo at the front of the queue, removes it once finished
	 */
	void doJob(){
		if (workQueue.peek().doWork()){		
			wallet += workQueue.peek().value;
			workQueue.remove();
		}		
	}

	public static void main(String args[]){
		
		Contractor myContractor = new Contractor();
		//initial job for the contractor
		myContractor.newJob();	
		
		while (myContractor.workLeft()){
			//work on the current job
			myContractor.doJob();
			//if successful in advertising a new job
			if (myContractor.advertiseContract()){	
				//add a new job to the queue
				myContractor.newJob();	
			}	
		}
		// print the summary of the job
		System.out.println(myContractor.summarizeWork());	
	}		
}
