/*
 * sree jessu
 * abstractCondo
 * 04/20/2021
 * a abstract house class that has variables used in other house classes
*/
package abstractJavaHouse;

public abstract class abstractHouse {
	
	// declare a variable for the number of floors in the house
	int numOfRooms;
	// declare a double variable for the value of each house
	double value;
	// declare a integer variable for the hours of work required to build the house
	int workRequired;
	// declare a integer variable that acts as a counter
	int workCounter;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each house
	 */
	abstract void calculateValue();
	
	/*
	 * sree jessu
	 * doWork
	 * 04/20/2021
	 * calculates the amount of work done for the houses
	 */
	boolean doWork(){
		return false;	
	}
	
	/*
	 * sree jessu
	 * driveway
	 * 04/20/2021
	 * checks whether or not the house has a driveway
	 */
	boolean driveway(){
		return false;	
	}
	
	/*
	 * sree jessu
	 * furnished
	 * 04/20/2021
	 * checks whether or not the house is furnished
	 */
	boolean furnished(){
		return false;	
	}
}
