/*
 * sree jessu
 * largeCondo
 * 04/20/2021
 * a large condo class that extends the abstract condo and inherits the variables
*/
package abstractJavaHouse;

public class largeCondo extends abstractCondo{
	
	// declare an integer variable that holds the number of floors
	int numOfFloors;
	// declare a boolean variable for the basement
	boolean Basement;
	// declare a boolean variable for painting
	boolean Painted;
	
	/*
	 * sree jessu
	 * calculateValue
	 * 04/20/2021
	 * calculates the value of each large condo
	 */
	@Override
	void calculateValue() {
		value = numOfFloors * 3000;
	}
	
	/*
	 * sree jessu
	 * basement
	 * 04/20/2021
	 * checks if there is basement and calculates the value and work required
	 */
	@Override
	boolean basement() {
		if (Basement = true){
			value = value + 400;
			workRequired = workRequired + 30;
		}
		else {
			return false;
		}
		return Basement;		
	}
	
	/*
	 * sree jessu
	 * painted
	 * 04/20/2021
	 * checks if the mini condo needs to be painted and calculates value and work required
	 */
	@Override
	boolean painted() {
		if (Painted = true){
			value = value + 800;
			workRequired = workRequired + 200;
		}
		else {
			return false;
		}
		return Painted;
	}
	
	/*
	 * sree jessu
	 * largeCondo
	 * 04/20/2021
	 * stores all the required variables for the large condo
	 */
	largeCondo(int floors, boolean hasBasement, boolean isPainted){	
		numOfFloors = floors;
		hasBasement = basement();
		isPainted = painted();
		calculateValue();
	}
}